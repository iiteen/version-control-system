#include <iostream>
#include <fstream>
#include <string>
#include <vector>

using namespace std;

struct MyData{
    int value;
    string name;
};

void saveDataToFile(const vector<MyData>& data, const string& filename){
    ofstream file(filename);
    if(!file.is_open()){
        cerr << "Error opening file for writing" << endl;
        return;
    }

    for(const MyData& item : data){
        file << item.value << " " << item.name << endl;
    }

    file.close();
    cout << "Data saved to file" << endl;
}

vector<MyData> loadDataFromFile(const string& filename){
    vector<MyData> data;
    ifstream file(filename);
    if(!file.is_open()){
        cerr << "Error opening file for reading" << endl;
        return data;
    }
    MyData item;
    while(file>>item.value>>item.name){
        data.push_back(item);
    }

    file.close();
    return data;
}

int main(){
    const string filename = "data.txt";

    // vector<MyData> loadedData = loadDataFromFile(filename);

    // for (int i = 0; i < 5; i++){
    //     loadedData.push_back({82, "baghel"});
    // }

    // saveDataToFile(loadedData, filename);

    cerr << "\033[1;31m" + filename + "\033[0m" << endl;
}